#!/bin/sh
cp -r remoteit/* /
connectd_mp_configure

